// REACHABILITY
public class J1_Reachable2 {
	
	public J1_Reachable2(){}
	
	public static int test() {
		int i = 1;
		;;;
		int j = 2;
		return 120 + j + i;
	}

}
