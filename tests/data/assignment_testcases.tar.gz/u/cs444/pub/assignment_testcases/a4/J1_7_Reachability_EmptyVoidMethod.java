// REACHABILITY

public class J1_7_Reachability_EmptyVoidMethod {
	public J1_7_Reachability_EmptyVoidMethod() {}
	
	public void empty() {}
	
	public static int test() {
		return 123;
	}
}
