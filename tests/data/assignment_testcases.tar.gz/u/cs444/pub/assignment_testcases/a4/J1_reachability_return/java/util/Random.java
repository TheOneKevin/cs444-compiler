package java.util;
public class Random {
    public Random() {
    }
    public boolean nextBoolean() {
        return true;
    }
}
