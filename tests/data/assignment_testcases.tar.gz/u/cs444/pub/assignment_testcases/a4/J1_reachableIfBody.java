// REACHABILITY
public class J1_reachableIfBody {

    public J1_reachableIfBody () {}

    public static int test() {
	if (false)
	    return 7;
        return 123;
    }

}
