// REACHABILITY,CODE_GENERATION
public class J1_whiletrue1 {
	public J1_whiletrue1() { }
	public static int test() {
		return 123;
	}
	public static void foo() {
		while(true);
	}
	
}
