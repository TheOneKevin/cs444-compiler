// REACHABILITY
public class J1_Reachable3 {
	
	public J1_Reachable3(){}
	
	public static int test() {
		int h = 1;
		
		{
		
		}
		
		int j = 2;
		return 120 + j + h;
	}

}
