// REACHABILITY
public class J1_unreachableAutomation {

    public J1_unreachableAutomation () {}

    public static int test() {
	int x = 1135104544;
	while (1184>x) {
	    return 7;
	}
	String s1 =  "foo97";
	return 123;
    }


}
