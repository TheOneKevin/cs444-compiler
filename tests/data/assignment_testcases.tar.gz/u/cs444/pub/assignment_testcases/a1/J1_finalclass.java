// PARSER_WEEDER
public final class J1_finalclass {

    public J1_finalclass() {}

    public static int test() {
	return 123;
    }

}
