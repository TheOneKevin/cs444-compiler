// PARSER_WEEDER
public/**/class/*H*/J1_hello_comment/*e*/{/*ll*/
    public/*o*/
	J1_hello_comment/*,*/
	(/* */
        )/*w*/
	{/*o*/
	}/*r*/
    /*l*//*d*/ //!
    // :-)
    /*H*/public/*o*/static/*w*/int/* */test/*a*/(/*r*/)/*e*/{// 
	String/*y*/s/*o*/=/*u*/"Hello, World!"/*?*/;
	/* */System/*I*/./* */out/*a*/./*m*/println/* */(/*f*/s/*i*/)/*n*/;/*e*/
	int/*,*/r/* */=/*t*/0/*h*/;/*a*/
	for/*n*/(/*k*/int/* */i/*y*/=/*o*/0/*u*/;/*.*/i/* */</*A*/s/*n*/./*d*/length/* */(/*h*/)/*o*/;/*w*/ /* */i/*i*/=/*s*/i/* */+/*y*/1/*o*/)/*u*/ {//r
/*	    */r/*a*/=/*u*/17/*n*/*/*t*/r/*?*/+/* */s/*J*/./*o*/charAt/*l*/(/*l*/i/*y*/)/* */;/* g*/
        /*o*/}/*o*/
	/*d*/return/*.*/248113298/*.*/+/*.*/r/* */;// See
    /*y*/}/*o*/
/*u*/}// then, goodbye.

