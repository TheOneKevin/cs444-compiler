// PARSER_WEEDER
public class J1_BigInt {

    public J1_BigInt(){}

       public static int test() {

	   return 2147483647 - 2147483524;
       }
}

