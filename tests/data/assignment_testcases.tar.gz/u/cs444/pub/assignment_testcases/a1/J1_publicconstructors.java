// PARSER_WEEDER
public class J1_publicconstructors {
    public J1_publicconstructors() {}
    public static int test() {
	return 123;
    }
}
