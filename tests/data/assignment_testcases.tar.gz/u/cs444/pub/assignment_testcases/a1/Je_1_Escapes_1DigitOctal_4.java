// JOOS1:PARSER_WEEDER,LEXER_EXCEPTION
// JOOS2:PARSER_WEEDER,LEXER_EXCEPTION
// JAVAC:UNKNOWN
// 
/**
 * Parser/Weeder
 * - Add character escapes.
 */
public class Je_1_Escapes_1DigitOctal_4{

    public Je_1_Escapes_1DigitOctal_4() {}

    public static int test(){
 	String c = "\9";
	return 123;
    }
}
