// PARSER_WEEDER,CODE_GENERATION
public class J1_arithmeticoperations {
    public J1_arithmeticoperations() {}
    public static int test() {
	int x = 17;
	int y = -2*x+87%x-(x/7);
	return x+106;
    }
}
