// PARSER_WEEDER
public abstract class J1_abstractmethodwithoutbody {

    public J1_abstractmethodwithoutbody() {}

    public abstract void flimflam();

    public static int test() {
	return 123;
    }

}
