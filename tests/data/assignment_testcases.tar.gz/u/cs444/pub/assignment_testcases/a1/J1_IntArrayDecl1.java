// PARSER_WEEDER
public class J1_IntArrayDecl1{

    public J1_IntArrayDecl1(){}

    public static int test(){
	    int[] a = new int[5];
	    return 123;
    }
}

