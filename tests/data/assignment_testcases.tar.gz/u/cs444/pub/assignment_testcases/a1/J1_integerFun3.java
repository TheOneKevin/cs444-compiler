// PARSER_WEEDER
public class J1_integerFun3 {

    public J1_integerFun3 () {}

    public static int test() {
	if ((641 * 6700417) == 1)
	    return 123;
        return 7;
    }

    public static void main(String[] args) {
	System.out.println(J1_integerFun3.test());
    }
}
