// PARSER_WEEDER
public class J1_intliterals {
    public J1_intliterals() {}
    public static int test() {
	return 123;
    }
}
