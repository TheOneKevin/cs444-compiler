// PARSER_WEEDER
public class J1_nullliteral {
    public J1_nullliteral() {}
    public static int test() {
	Object o = null;
	return 123;
    }
}
