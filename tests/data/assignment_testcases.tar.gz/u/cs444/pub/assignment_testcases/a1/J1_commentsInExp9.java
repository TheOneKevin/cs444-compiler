// PARSER_WEEDER
public class J1_commentsInExp9 {

    public J1_commentsInExp9 () {}

    public static int test() {
        return (126) /* Java rocks */ - /* foo */ 3;
    }

}
