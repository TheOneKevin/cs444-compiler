//PARSER_WEEDER
//JOOS1:PARSER_EXCEPTION
//JOOS2:PARSER_EXCEPTION

public class Je_1_IncDec_DecMinus {
	public Je_1_IncDec_DecMinus() {}
	
	public static int test() {
		int i = 123;
		return +++i;
	}
}

