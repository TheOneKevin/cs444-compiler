// JOOS1:PARSER_WEEDER,LEXER_EXCEPTION
// JOOS2:PARSER_WEEDER,LEXER_EXCEPTION
// JAVAC:UNKNOWN
// 
/**
 * Parser/Weeder
 * - Add character escapes.
 */
public class Je_1_Escapes_3DigitOctal_3{

    public Je_1_Escapes_3DigitOctal_3() {}

    public static int test(){
	char s = '\400';
	return 123;
    }
}
