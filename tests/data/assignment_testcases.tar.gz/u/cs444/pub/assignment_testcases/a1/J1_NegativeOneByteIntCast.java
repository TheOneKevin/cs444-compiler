// PARSER_WEEDER,CODE_GENERATION
public class J1_NegativeOneByteIntCast {

    public J1_NegativeOneByteIntCast(){}

       public static int test() {

	   return (int)-123 + 246;
       }
}

