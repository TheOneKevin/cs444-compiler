public class Je_Native {
    public native int m();
}
