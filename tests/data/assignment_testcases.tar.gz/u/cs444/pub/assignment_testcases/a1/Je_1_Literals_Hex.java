// PARSER_WEEDER
// JOOS1: PARSER_EXCEPTION
// JOOS2: PARSER_EXCEPTION
// JAVAC:
/**
 * Parser/weeder:
 * - Hex literals not allowed.
 */
public class Je_1_Literals_Hex{

    public Je_1_Literals_Hex(){}

    public static int test(){
	return 0x7B;
    }
}
