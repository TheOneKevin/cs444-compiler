// PARSER_WEEDER
public class J1_charliterals {
    public J1_charliterals() {}
    public static int test() {
	char c1 = 'a';
	char c2 = '7';
	return 123;
    }
}
