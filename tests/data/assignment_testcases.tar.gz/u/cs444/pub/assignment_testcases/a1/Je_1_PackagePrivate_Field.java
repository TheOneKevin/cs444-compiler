// JOOS1:PARSER_WEEDER,PARSER_EXCEPTION
// JOOS2:PARSER_WEEDER,PARSER_EXCEPTION
// JAVAC:
public class Je_1_PackagePrivate_Field {

    int x;

    public Je_1_PackagePrivate_Field() { }

    public static int test() {
	return 123;
    }
}
