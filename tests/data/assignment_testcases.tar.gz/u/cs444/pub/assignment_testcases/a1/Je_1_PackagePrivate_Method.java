// JOOS1:PARSER_WEEDER,PARSER_EXCEPTION
// JOOS2:PARSER_WEEDER,PARSER_EXCEPTION
// JAVAC:
public class Je_1_PackagePrivate_Method {

    public Je_1_PackagePrivate_Method() {}

    public static int test() {
		return 123;
    }

    static void packagePrivateMethod() {
    }
}
