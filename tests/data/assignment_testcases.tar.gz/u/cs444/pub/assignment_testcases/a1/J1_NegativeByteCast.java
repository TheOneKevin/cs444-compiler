// PARSER_WEEDER,CODE_GENERATION
public class J1_NegativeByteCast {

    public J1_NegativeByteCast(){}

       public static int test() {

	   return (byte)-123456 + 187;
       }
}
