// PARSER_WEEDER
public class J1_octal_escape2 {
    public J1_octal_escape2() {}
    public static int test() {return (int)'\173';}
}
