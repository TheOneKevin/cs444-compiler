// PARSER_WEEDER
public class J1_intminusfoo {
    public J1_intminusfoo(){}

    public static int test() {
	int foo = -123;
	return (int)-foo;    
    }
}
