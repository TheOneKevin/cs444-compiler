// PARSER_WEEDER
public abstract class J1_abstractclass {

    public J1_abstractclass() {}

    public static int test() {
	return 123;
    }
    
}
