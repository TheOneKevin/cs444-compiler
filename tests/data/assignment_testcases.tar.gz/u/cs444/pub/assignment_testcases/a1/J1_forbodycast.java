// PARSER_WEEDER
public class J1_forbodycast {

    public J1_forbodycast() {}

    public static int test() {
	String String = "Hello";
	for (int i=0; i<10; i=i+1) {
	    String = (String)+(String)"World";
	}
	return String.length()+68;
    }


}
