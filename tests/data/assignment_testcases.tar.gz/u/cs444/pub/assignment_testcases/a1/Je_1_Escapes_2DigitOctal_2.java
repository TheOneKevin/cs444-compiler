// JOOS1:PARSER_WEEDER,LEXER_EXCEPTION
// JOOS2:PARSER_WEEDER,LEXER_EXCEPTION
// JAVAC:UNKNOWN
// 
/**
 * Parser/Weeder
 * - Add character escapes.
 */
public class Je_1_Escapes_2DigitOctal_2{

    public Je_1_Escapes_2DigitOctal_2() {}

    public static int test(){
	char s = '\80';
	return 123;
    }
}

