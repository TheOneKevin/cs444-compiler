public class A {
    public A() {}
    public int m() throws java.lang.Exception {
        return 42;
    }
}

