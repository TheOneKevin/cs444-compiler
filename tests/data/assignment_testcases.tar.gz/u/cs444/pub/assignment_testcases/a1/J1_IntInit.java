// PARSER_WEEDER
public class J1_IntInit {

    public J1_IntInit(){}

	public static int test() {
		int x = 123456;
		return x - 123333;
	}
}

