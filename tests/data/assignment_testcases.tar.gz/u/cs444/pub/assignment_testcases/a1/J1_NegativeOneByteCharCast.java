// PARSER_WEEDER,CODE_GENERATION
public class J1_NegativeOneByteCharCast {
    
    public J1_NegativeOneByteCharCast(){}
    
    public static int test() {
	return (char)-123 - 65290;
    }
}

