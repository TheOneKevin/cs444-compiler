// JOOS1:PARSER_WEEDER,INVALID_SOURCE_FILE_NAME
// JOOS2:PARSER_WEEDER,INVALID_SOURCE_FILE_NAME
// JAVAC:UNKNOWN
// 
public class Je_1_ClassDeclaration_WrongFileName_Dot {
	public Je_1_ClassDeclaration_WrongFileName_Dot() {}
	
	public static int test() {
		return 123;
	}
}
