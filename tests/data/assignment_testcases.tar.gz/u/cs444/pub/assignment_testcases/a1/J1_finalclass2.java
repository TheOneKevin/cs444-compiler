// PARSER_WEEDER
public final class J1_finalclass2 {
	public J1_finalclass2() { }
	public static int test() { return 123; }
}
