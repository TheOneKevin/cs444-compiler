// PARSER_WEEDER,CODE_GENERATION
public class J1_minusminusminus {

    public J1_minusminusminus() {}

    public static int test() {
	int x = - - - -123;
	return x;
    }

}
