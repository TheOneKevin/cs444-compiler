// PARSER_WEEDER
public class J1_IntArrayDecl2{

    public J1_IntArrayDecl2(){}

    public static int test(){
	    (new int[5])[2] = 42;
	    return 123;
    }
}

