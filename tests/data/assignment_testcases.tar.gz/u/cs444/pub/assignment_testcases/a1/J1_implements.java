// PARSER_WEEDER
public class J1_implements implements java.io.Serializable {

    public J1_implements() {}

    public int x;

    public static int test() {
	return 123;
    }

}
