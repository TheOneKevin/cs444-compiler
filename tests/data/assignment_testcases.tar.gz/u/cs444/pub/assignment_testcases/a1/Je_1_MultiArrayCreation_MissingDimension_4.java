//PARSER_WEEDER
//JOOS1:PARSER_EXCEPTION
//JOOS2:PARSER_EXCEPTION
//JAVAC:UNKNOWN

public class Je_1_MultiArrayCreation_MissingDimension_4 {
	
	public Je_1_MultiArrayCreation_MissingDimension_4() {}

	public static int test() {
		int[][][] array = new int[2][][2];
		return 123;
	}
	
}
