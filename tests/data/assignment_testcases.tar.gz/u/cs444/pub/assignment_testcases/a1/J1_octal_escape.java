// PARSER_WEEDER
public class J1_octal_escape {
    public J1_octal_escape() {}
    public static int test() {return 3*(int)'\051';}
}
