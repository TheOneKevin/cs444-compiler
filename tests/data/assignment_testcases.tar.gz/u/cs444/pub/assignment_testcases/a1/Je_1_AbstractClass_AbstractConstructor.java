// JOOS1:PARSER_WEEDER,PARSER_EXCEPTION
// JOOS2:PARSER_WEEDER,PARSER_EXCEPTION
// JAVAC:UNKNOWN
/**
 * Parser/weeder:
 * - A constructor must not be abstract.
 */
public abstract class Je_1_AbstractClass_AbstractConstructor{

    public abstract Je_1_AbstractClass_AbstractConstructor();

}
