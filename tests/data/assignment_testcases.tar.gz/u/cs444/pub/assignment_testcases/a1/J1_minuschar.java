// PARSER_WEEDER,CODE_GENERATION
public class J1_minuschar {
    public J1_minuschar() {}
    public static int test() {return - - '{';}
}
