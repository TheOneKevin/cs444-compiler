// PARSER_WEEDER
public class J1_staticmethoddeclaration {

  public J1_staticmethoddeclaration() {}

  public static int test() {
    return 123;
  }

}
