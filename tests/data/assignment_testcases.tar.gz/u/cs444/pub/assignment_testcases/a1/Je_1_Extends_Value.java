// JOOS1:PARSER_WEEDER,PARSER_EXCEPTION
// JOOS2:PARSER_WEEDER,PARSER_EXCEPTION
// JAVAC:UNKNOWN
// 
/**
 * Parser/weeder:
 * - Values cannot be extended
 */
public class Je_1_Extends_Value extends 4 {

    public Je_1_Extends_Value() { }

    public static int test() { 
	return 123; 
    }

}
