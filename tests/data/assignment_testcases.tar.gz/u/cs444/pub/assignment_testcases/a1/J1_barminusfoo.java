// PARSER_WEEDER
public class J1_barminusfoo {
    public J1_barminusfoo(){}

    public static int test() {
	int foo = -123;
	int bar = 0;
	return (bar)-foo;
    }
}
