public class A {
    public A() {}
    
    public static void method() {}
}
