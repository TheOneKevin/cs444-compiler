public class foo {
    
    public int x;

    public foo() {
	x = 123;	
    }
}

