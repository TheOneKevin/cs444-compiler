
public interface Foo {
	
	public int test2();

}
