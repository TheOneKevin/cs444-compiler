// ENVIRONMENTS
public class J1_noduplicatefield {
	public int foo;
	public int bar;
	public int FOO;

	public J1_noduplicatefield() { }
	public static int test() { return 123; }
}
