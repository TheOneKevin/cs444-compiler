// TYPE_LINKING,HIERARCHY
import java.io.Serializable;
public class Main implements Serializable {

    public Main() {}

    public static int test() {
	return 123;
    }

}
