// ENVIRONMENTS
/**
 * - Environments
 * Check that no two fields in the same class have the same name.
 */
public class J1_2_Fields_Case {

    public Object foo;

    public Object Foo;

    public J1_2_Fields_Case () {}

    public static int test() {
        return 123;
    }

}
