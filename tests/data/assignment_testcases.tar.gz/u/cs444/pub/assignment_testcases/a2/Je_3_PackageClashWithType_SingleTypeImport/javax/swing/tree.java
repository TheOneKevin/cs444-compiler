package javax.swing;

public class tree {
	public tree() {}
}
