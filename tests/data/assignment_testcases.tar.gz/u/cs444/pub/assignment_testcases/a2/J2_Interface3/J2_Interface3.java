
public interface J2_Interface3 {
	public int test1();
	
	public int test1(int kj);
	
	public int test2();
}
