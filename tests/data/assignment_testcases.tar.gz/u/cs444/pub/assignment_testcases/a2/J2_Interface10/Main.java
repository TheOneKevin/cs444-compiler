// JOOS1: PARSER_WEEDER,PARSER_EXCEPTION,JOOS1_INTERFACE
// JOOS2: HIERARCHY

public class Main implements Foo {

	public Main(){}
	
	public static int test() {
		return 123;
	}
	
	public int test2() {
		return 0;
	}

}
