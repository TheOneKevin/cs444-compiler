package javax.naming;
public interface Name {
    public Object clone();
}
