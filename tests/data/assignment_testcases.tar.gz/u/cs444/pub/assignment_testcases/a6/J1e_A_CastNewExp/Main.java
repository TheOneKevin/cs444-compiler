// CODE_GENERATION

import javax.swing.*;

public class Main {
	public Main() {}
	
	public static int test() {
		JButton s = (JButton)new JComponent();
		return 123;
	}
}
