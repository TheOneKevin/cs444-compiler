// TYPE_CHECKING,CODE_GENERATION
public class J1_instanceof_array2 {
    public J1_instanceof_array2() {}
    public static int test() {return 123;}
    public boolean foo(Object o) {
	return o instanceof Object[];
    }
}
