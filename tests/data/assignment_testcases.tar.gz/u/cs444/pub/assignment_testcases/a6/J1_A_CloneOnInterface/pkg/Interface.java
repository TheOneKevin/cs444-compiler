// CODE_GENERATION
package pkg;

public interface Interface {
    public Object clone();
}
