// CODE_GENERATION
public class J1_StringCast{
    
    public J1_StringCast(){}

    public static int test () {
	String a = (String)"123";
	return Integer.parseInt(a);
    }
}
