// CODE_GENERATION
public class J1_WildConcat {
    protected int x;

    public J1_WildConcat() {}

    public static int test() {
	return new J1_WildConcat().concat()-295343374;
    }

    public String foo() {
	String result = ""+(x = x+1);
	if ((x % 3) == 0) result = null;
	return result;
    }

    public int concat() {
	int n = 10;
	int sum = 0;
	while (n > 0) {
	    String s = ((foo()+(foo()+(foo()+(foo()+foo()))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))))+((foo()+(foo()+(foo()+foo())))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))))))))))))+((foo()+(foo()+(foo()+(foo()+foo()))))+((foo()+(foo()+((foo()+foo())+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))))))))))))))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))))))))))+(((foo()+foo())+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))))))))))))))+((foo()+(foo()+(foo()+(foo()+(foo()+foo())))))+((foo()+foo())+((foo()+(foo()+foo()))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))))+((foo()+(foo()+foo()))+((foo()+(foo()+foo()))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))))))+((foo()+(foo()+foo()))+((foo()+(foo()+foo()))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))))+((foo()+foo())+(foo()+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))+((foo()+foo())+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))+((foo()+(foo()+(foo()+(foo()+(foo()+foo())))))+((foo()+(foo()+(foo()+(foo()+(foo()+foo())))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))))+(foo()+((foo()+(foo()+(foo()+(foo()+(foo()+foo())))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))))))+((foo()+(foo()+(foo()+(foo()+foo()))))+((foo()+(foo()+foo()))+((foo()+(foo()+(foo()+(foo()+(foo()+foo())))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))+((foo()+(foo()+foo()))+((foo()+(foo()+(foo()+foo())))+((foo()+(foo()+(foo()+foo())))+(foo()+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))+((foo()+(foo()+(foo()+foo())))+((foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo()))))))+((foo()+(foo()+(foo()+foo())))+(foo()+((foo()+(foo()+(foo()+foo())))+((foo()+(foo()+(foo()+(foo()+foo()))))+((foo()+(foo()+(foo()+(foo()+(foo()+foo())))))+((foo()+(foo()+(foo()+foo())))+((foo()+(foo()+(foo()+foo())))+(foo()+((foo()+(foo()+foo()))+((foo()+(foo()+(foo()+(foo()+foo()))))+((foo()+foo())+((foo()+(foo()+(foo()+(foo()+foo()))))+((foo()+(foo()+foo()))+((foo()+(foo()+(foo()+(foo()+(foo()+foo())))))+((foo()+(foo()+(foo()+foo())))+((foo()+(foo()+foo()))+((foo()+foo())+((foo()+(foo()+(foo()+foo())))+((foo()+(foo()+(foo()+(foo()+foo()))))+(foo()+((foo()+(foo()+foo()))+((foo()+(foo()+foo()))+((foo()+foo())+((foo()+(foo()+(foo()+foo())))+(foo()+((foo()+foo())+((foo()+(foo()+(foo()+foo())))+((foo()+foo())+((foo()+foo())+((foo()+(foo()+foo()))+((foo()+foo())+(foo()+((foo()+foo())+((foo()+foo())+((foo()+foo())+((foo()+(foo()+foo()))+(foo()+((foo()+foo())+(foo()+(foo()+((foo()+foo())+((foo()+foo())+(foo()+(foo()+((foo()+foo())+(foo()+(foo()+(foo()+(foo()+((foo()+foo())+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+(foo()+foo())))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
	    sum = sum + s.hashCode();
	    n = n-1;
	}
	return sum;
    }
}
