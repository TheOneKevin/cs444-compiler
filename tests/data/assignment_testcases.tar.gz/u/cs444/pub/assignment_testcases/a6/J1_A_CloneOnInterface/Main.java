// CODE_GENERATION
import pkg.*;

public class Main {
	public Main() {}
	
	public static int test() {
		Interface a = new pkg.Class();
		Object o = a.clone(); 
		return 123;
	}
}
