package util;

public interface Collection {
    public int size();
    public boolean empty();
}
