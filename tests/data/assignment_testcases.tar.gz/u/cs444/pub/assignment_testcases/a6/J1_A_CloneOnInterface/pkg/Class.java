// CODE_GENERATION
package pkg;

public class Class implements Interface {
    public Class() {}
    public Object clone() { return this; }
}
