package shapes;

public interface Shape {
  public int getArea();
}
