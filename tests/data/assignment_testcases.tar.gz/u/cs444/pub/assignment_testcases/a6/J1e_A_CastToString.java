// CODE_GENERATION

public class J1e_A_CastToString {
	public J1e_A_CastToString() {}
	
	public static int test() {
		Object i = new Integer(123);
		String s = (String)i;
		return 123;
	}
}
