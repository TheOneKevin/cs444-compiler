package java.util;
public interface List extends Collection {
    public int size();
}
