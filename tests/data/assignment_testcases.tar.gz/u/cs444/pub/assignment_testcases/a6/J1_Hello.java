public class J1_Hello {
    public J1_Hello() {}
    public static int test() {
        System.out.println("Hello, World!");
        return 123;
    }
}
