package shapes;

public interface Resizable {
    public void resize(int factor);
}
