package shapes;

public interface Colorable {
    public void setColor(String color);
    public int colorToInt();
}
